#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void inverter(char str[]) {
    int i, j;
    char txt[20];
    for ( i = 0, j = strlen(str)-1; i < strlen(str); i++, j--)
        txt[i] = str[j];
    if (atoi(txt) == atoi(str)) printf("%d\n", atoi(txt));
}

int main () {
    char str[20];
    int i = 0, n;
    do
    {
        for ( i = 1; i <= 9999; i++)
        {
            itoa(i, str, 10);
            inverter(str);
        }
        printf("\n");
        scanf("%d", &n);
    } while (n != 0);
}