#include <stdio.h>
#include <stdlib.h>

#define H 30
#define M 20

int main() {
    int i, j, h, m,    
}