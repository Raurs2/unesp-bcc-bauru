#include <stdio.h>

int main() {
    int biblio[8][40][150], livros[200][35][60];
    printf("%zu bytes", sizeof(biblio) + sizeof(livros));
    
}