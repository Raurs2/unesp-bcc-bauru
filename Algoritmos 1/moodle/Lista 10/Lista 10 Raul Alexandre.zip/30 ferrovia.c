#include <stdio.h>
#include <stdlib.h>

#define lin 6
#define col 6

int main() {
    int i, j, n, dest, ori;
    int a[lin][col] = {{0, 100, 15, 0, 0, 0}, {100, 0, 40, 180, 200, 0}, {15, 40, 0, 45, 95, 0}, {0, 180, 45, 0, 0, 105}, {0, 200, 35, 0, 0, 120}, {0, 0, 0, 105, 120, 0}};
    do
    {
        scanf("%d %d", &dest, &ori);
        do
        {
            
        } while ();
        
        printf("\nContinuar?\n");
        scanf("%d", &n);
        system("cls");
    } while (n != 0);
    
    return 0;
}