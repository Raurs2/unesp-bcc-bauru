#include <stdio.h>
#include <math.h>
#include <string.h>

int main() {
    int n,sum = 0, i = 1, j, max, r;
    scanf("%d", &n);
    r = n*n*n;
    for (i = 1, max = 5; i; i += 2, max += 2)
    {
            for ( j = i, sum = 0; j <= max; j += 2)
            {
                sum += j;
            } 
        if (sum == r) break;
        
    }
    
    printf("%d, %d", sum, r);
    
    return 0;    
}