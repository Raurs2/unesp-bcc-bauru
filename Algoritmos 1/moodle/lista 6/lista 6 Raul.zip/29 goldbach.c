#include <stdio.h>
int primo(int n) {
    int i, sum;
    for ( i = 1, sum = 0; i <= n; i++)
            if (n % i == 0) sum += i;
    if (sum == 1 + n) return 1;
    else return 0;
}
int main() {
    int i, j, r, n, sum;
    for (n = 500; n <= 1300; n++)
        for (i = 2; i <= n/2; i++)
            if (primo(i) && primo(n - i)) printf("%d = %d + %d\n", n, i, n-i);
    return 0;    
}