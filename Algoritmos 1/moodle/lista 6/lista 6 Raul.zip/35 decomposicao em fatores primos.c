#include <stdio.h>
#include <math.h>
#include <string.h>

int primo(int n) {
    int i, sum;
    for (i = 1, sum = 0; i <= n; i++)
    {
        if (n % i == 0) sum += i;
    }
    if (sum == n + 1) return n;
    else return 1;
}

int main() {
    int n, i, x;
    scanf("%d", &n);

    for ( i = 2; i <= n;)
    {
        x = primo(i);

        if (n % x == 0 && x != 1)
        {
            printf("%d", i);
            if (i < n) printf(" x ");
            n /= i;
            continue;
        }
        
        i++;
    }
    
    return 0;    
}