
#include<stdio.h>

double calculaSerie(double n)
{

    
}
 

int main()
{
    int n1, n2, t1, t2;

    scanf("%d %d %d %d", &n1, &n2, &t1, &t2);

    printf("%lf", calculaSerie());
 
    return 0;
}